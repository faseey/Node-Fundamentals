const express = require("express")
const {getUser}= require("../service/auth") 



function checkAuth(req,res,next){
    req.user = null;

    const token = req.cookies?.token;

    if(!token){
        return res.redirect("/user")
    }

    const user = getUser(token);
    if(!user){
       return  res.redirect("/user/");
    }
    req.user = user;
    next();
}

module.exports =  {checkAuth}